# Design of 28 GHz Microstrip Patch Antenna

## Project Overview
A 28 GHz microstrip patch antenna designed for high-frequency wireless applications. The antenna was modeled and analyzed using CST Microwave Studio.

## Objectives
- Design a microstrip patch antenna operating around 28 GHz.
- Simulate the antenna using CST Microwave Studio.
- Analyze important antenna performance parameters.
- Study the effect of substrate material on antenna performance.

## Software
- CST Microwave Studio

## Antenna Parameters
The design was analyzed using:
- Return Loss (S11)
- VSWR
- Gain
- Radiation Pattern

## Substrate
Rogers RT/Duroid 5880 was used as a substrate material because of its suitable high-frequency characteristics and low dielectric constant.

## Working / Methodology
1. Select the target operating frequency of 28 GHz.
2. Select the substrate material and thickness.
3. Calculate initial patch dimensions.
4. Create the patch, substrate, ground plane, and feed in CST.
5. Set the required excitation/feed.
6. Run the electromagnetic simulation.
7. Analyze S11/return loss and VSWR around 28 GHz.
8. Analyze gain and radiation pattern.
9. Tune the geometry if required to improve performance.

## Performance Parameters

### Return Loss
Return loss indicates how much input power is reflected from the antenna. A more negative S11 value around the target frequency generally indicates better impedance matching.

### VSWR
Voltage Standing Wave Ratio indicates the quality of impedance matching between the antenna and feed line. A value close to 1 indicates good matching.

### Gain
Gain represents the antenna's ability to direct radiated power in a particular direction while accounting for antenna efficiency.

### Radiation Pattern
The radiation pattern shows how the antenna radiates energy in different directions.

## Result
A 28 GHz microstrip patch antenna was designed and simulated in CST Microwave Studio, and its return loss, VSWR, gain, and radiation pattern were analyzed.

## Future Improvements
- Optimize the feed position and patch dimensions.
- Compare additional substrate materials.
- Develop and analyze a 2×2 antenna array.
- Optimize bandwidth and gain for 5G applications.

## Skills Demonstrated
- CST Microwave Studio
- Microstrip antenna design
- RF and microwave engineering
- Antenna parameter analysis
- 28 GHz / 5G-oriented design

## Author
Kiran Metagudda
